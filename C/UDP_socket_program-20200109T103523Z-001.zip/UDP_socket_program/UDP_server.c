#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

#define PORT  8080  

int main()
{ 
	int sockfd; 
	char buffer[1024]; 
	struct sockaddr_in servaddr, cliaddr;
	int len, n;

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0) 
		printf("\nSocket creation failed");
	else
		printf("Socket created successfully");

	memset(&servaddr, 0, sizeof(servaddr)); 
	memset(&cliaddr, 0, sizeof(cliaddr)); 
	servaddr.sin_family    = AF_INET; 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT); 

	if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) 
		printf("\nBinding failed");
	else
		printf("\nBinding Successful");
	
	n = recvfrom(sockfd, (char *)buffer,1024,MSG_WAITALL, ( struct sockaddr *) &cliaddr,&len); 
	buffer[n] = '\0'; 
	printf("\nData from client : %s\n", buffer); 

	return 0; 
}
